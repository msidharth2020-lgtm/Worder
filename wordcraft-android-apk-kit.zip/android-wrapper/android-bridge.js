/*
 * Android bridge for WordCraft's web build (loaded only inside the Capacitor APK).
 *
 * Why this exists: WordCraft's web build saves and exports by clicking a hidden
 * <a download href="blob:..."> link. Android WebView has no download handler, so inside the
 * APK that click would do nothing and "Save" would silently fail. This script catches that
 * click, writes the bytes to the app's cache folder and opens Android's share sheet, from
 * where you can pick "Save to Files", Drive, WhatsApp, email and so on.
 *
 * In a normal browser (no window.Capacitor) the script does nothing.
 */
(function () {
  'use strict';

  var cap = window.Capacitor;
  if (!cap || typeof cap.nativePromise !== 'function') return;
  if (typeof cap.isNativePlatform === 'function' && !cap.isNativePlatform()) return;

  var originalClick = HTMLAnchorElement.prototype.click;

  function safeName(name) {
    var n = String(name || '').replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_').trim();
    if (!n || n === '.' || n === '..') n = 'document';
    return n.length > 120 ? n.slice(-120) : n;
  }

  function toBase64(buffer) {
    var bytes = new Uint8Array(buffer);
    var chunk = 0x8000;
    var out = '';
    for (var i = 0; i < bytes.length; i += chunk) {
      out += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
    }
    return btoa(out);
  }

  async function saveAndShare(blobUrl, name) {
    var response = await fetch(blobUrl);
    var buffer = await response.arrayBuffer();
    var written = await cap.nativePromise('Filesystem', 'writeFile', {
      path: 'exports/' + name,
      directory: 'CACHE',
      data: toBase64(buffer),
      recursive: true
    });
    await cap.nativePromise('Share', 'share', {
      title: name,
      url: written.uri,
      dialogTitle: 'Save or send ' + name
    });
  }

  HTMLAnchorElement.prototype.click = function () {
    var anchor = this;
    var href = anchor.href || '';
    if (anchor.hasAttribute('download') && href.indexOf('blob:') === 0) {
      saveAndShare(href, safeName(anchor.getAttribute('download'))).catch(function (err) {
        var message = (err && (err.message || err.errorMessage)) || String(err);
        // Closing the share sheet without choosing anything is not an error.
        if (/cancel|dismiss/i.test(message)) return;
        console.error('WordCraft Android save failed:', err);
        alert('Could not save the file: ' + message);
      });
      return;
    }
    return originalClick.apply(anchor, arguments);
  };
})();
