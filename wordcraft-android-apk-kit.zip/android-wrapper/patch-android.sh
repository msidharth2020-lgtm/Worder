#!/usr/bin/env bash
# Patch the Android project that `npx cap add android` generated: version numbers and app icon.
#
# Usage: patch-android.sh <android dir> <icon png> <version name> <version code>
set -euo pipefail

ANDROID="${1:?usage: patch-android.sh <android dir> <icon png> <version name> <version code>}"
ICON="${2:?missing icon png}"
VERSION_NAME="${3:?missing version name}"
VERSION_CODE="${4:?missing version code}"

GRADLE="$ANDROID/app/build.gradle"
RES="$ANDROID/app/src/main/res"
[ -f "$GRADLE" ] || { echo "error: $GRADLE not found" >&2; exit 1; }
[ -d "$RES" ] || { echo "error: $RES not found" >&2; exit 1; }
[ -f "$ICON" ] || { echo "error: icon $ICON not found" >&2; exit 1; }

# Version: Capacitor's template has `versionCode 1` and `versionName "1.0"`.
sed -i -E "s/^([[:space:]]*)versionCode [0-9]+/\1versionCode ${VERSION_CODE}/" "$GRADLE"
sed -i -E "s/^([[:space:]]*)versionName \"[^\"]*\"/\1versionName \"${VERSION_NAME}\"/" "$GRADLE"
grep -q "versionCode ${VERSION_CODE}\$" "$GRADLE" || { echo "error: versionCode patch failed" >&2; exit 1; }
grep -q "versionName \"${VERSION_NAME}\"" "$GRADLE" || { echo "error: versionName patch failed" >&2; exit 1; }

# Icon: replace the default Capacitor launcher PNGs and drop the adaptive-icon XML so the PNGs are
# used on every Android version.
if command -v magick >/dev/null 2>&1; then IM=(magick); else IM=(convert); fi
command -v "${IM[0]}" >/dev/null 2>&1 || { echo "error: ImageMagick (convert/magick) not found" >&2; exit 1; }
for pair in mdpi:48 hdpi:72 xhdpi:96 xxhdpi:144 xxxhdpi:192; do
  density="${pair%%:*}"
  size="${pair##*:}"
  dir="$RES/mipmap-$density"
  mkdir -p "$dir"
  "${IM[@]}" "$ICON" -resize "${size}x${size}" "$dir/ic_launcher.png"
  cp "$dir/ic_launcher.png" "$dir/ic_launcher_round.png"
  rm -f "$dir/ic_launcher_foreground.png"
done
rm -rf "$RES/mipmap-anydpi-v26"

echo "patched $ANDROID: versionName=$VERSION_NAME versionCode=$VERSION_CODE, launcher icons replaced"
