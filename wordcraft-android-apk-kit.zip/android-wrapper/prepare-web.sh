#!/usr/bin/env bash
# Turn WordCraft's trunk output into the folder the Android wrapper packages (and a PWA you can host).
#
# Usage: prepare-web.sh <trunk dist dir> <output dir> <icon png>
#   e.g. android-wrapper/prepare-web.sh dist/web android-wrapper/www assets/app-icon/wordcraft-1024.png
#
# It copies the build, adds the Android save bridge and a web manifest, generates 192/512 px
# icons, and links all of that from index.html. The wasm app itself is not touched.
set -euo pipefail

SRC="${1:?usage: prepare-web.sh <trunk dist dir> <output dir> <icon png>}"
OUT="${2:?missing output dir}"
ICON="${3:?missing icon png}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

[ -f "$SRC/index.html" ] || { echo "error: $SRC/index.html missing; run trunk build first" >&2; exit 1; }
[ -f "$ICON" ] || { echo "error: icon $ICON not found" >&2; exit 1; }

# Same check as packaging/web/package.sh: the app must load everything through relative URLs.
if grep -Eq '(src|href)="/[^/]' "$SRC/index.html"; then
  echo "error: $SRC/index.html has root-absolute URLs; the APK serves it from its own origin" >&2
  exit 1
fi

if command -v magick >/dev/null 2>&1; then IM=(magick); else IM=(convert); fi
command -v "${IM[0]}" >/dev/null 2>&1 || { echo "error: ImageMagick (convert/magick) not found" >&2; exit 1; }

rm -rf "$OUT"
mkdir -p "$OUT"
cp -R "$SRC/." "$OUT/"
cp "$HERE/android-bridge.js" "$HERE/manifest.webmanifest" "$OUT/"
"${IM[@]}" "$ICON" -resize 192x192 "$OUT/icon-192.png"
"${IM[@]}" "$ICON" -resize 512x512 "$OUT/icon-512.png"

HEAD_TAGS='<link rel="manifest" href="manifest.webmanifest"><meta name="theme-color" content="#2b47b5"><script src="android-bridge.js"></script>'
grep -q '</head>' "$OUT/index.html" || { echo "error: no </head> in index.html" >&2; exit 1; }
sed -i "s|</head>|${HEAD_TAGS}</head>|" "$OUT/index.html"
grep -q 'android-bridge.js' "$OUT/index.html" || { echo "error: failed to patch index.html" >&2; exit 1; }

echo "prepared $OUT:"
ls -lh "$OUT" | sed 's/^/  /'
