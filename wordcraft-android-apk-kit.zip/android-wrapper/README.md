# WordCraft for Android (APK wrapper)

WordCraft has no native Android version. It does have a WebAssembly build that runs in a
browser. This folder wraps that build in a small Android app (using
[Capacitor](https://capacitorjs.com/)) so you can install it like any other app. Everything runs
on the phone; no server is involved. A GitHub Actions workflow does the build, so you need no PC
setup and nothing costs money.

## Get your APK

1. **Fork** https://github.com/storytold/wordcraft to your own GitHub account.
2. **Add these files to your fork**, keeping the same paths:
   - `.github/workflows/android-apk.yml`
   - `android-wrapper/` (this whole folder)

   On github.com: open your fork, *Add file > Upload files*, and drag the extracted `android-wrapper`
   folder in. For the workflow, use *Add file > Create new file*, type
   `.github/workflows/android-apk.yml` as the name, and paste the file's contents.
3. Open the **Actions** tab of your fork, pick **Android APK**, and press **Run workflow**. If
   GitHub asks you to enable workflows on the fork first, do that.
4. Wait. The first run is slow (roughly 20 to 40 minutes) because it compiles WordCraft to
   WebAssembly; later runs reuse a cache.
5. Open the finished run, download the **wordcraft-android-apk** artifact (a zip), and extract the
   `.apk`. Copy it to your phone.
6. Open the APK on the phone. Android will ask to allow installs from that app (Files, Chrome or
   whichever you used); allow it. Play Protect may warn about an unrecognised app. The APK is signed
   with a standard debug key, not a Play Store key, so that is expected.

The run also uploads **wordcraft-web-pwa**: the same web files, which you can host on any static
host (Cloudflare Pages, Netlify, GitHub Pages) and open in Chrome if you prefer that to an APK.

## What is in this folder

| File | Purpose |
|---|---|
| `package.json`, `package-lock.json` | Pinned Capacitor 8 packages |
| `capacitor.config.json` | App id `org.wordcraft.mobile`, name, web folder. Change the id if you like |
| `prepare-web.sh` | Copies the trunk build, adds the save bridge and web manifest, makes icons |
| `android-bridge.js` | Makes Save and Export work inside the APK (see below) |
| `manifest.webmanifest` | Web app manifest (name, colours, icons) |
| `patch-android.sh` | Sets the version and launcher icon in the generated Android project |

## How saving works on Android

The web version saves by clicking a hidden download link. Android WebView ignores those clicks, so
`android-bridge.js` catches them, writes the file to the app's cache and opens Android's share
sheet. Choose *Files*, *Drive*, email and so on to put the document where you want it. Opening files
uses Android's normal file picker.

## Known limits

- **Touch and on-screen keyboard are untested.** WordCraft's interface is built for mouse and
  keyboard (ribbon, rulers, shortcuts). Tapping and typing may be awkward, and a physical keyboard
  will feel much better. Please report what you see.
- **Printing** (the web version prints through a hidden frame) probably won't work in the APK.
  Export to PDF and share it instead.
- The first launch takes a few seconds while the 13 MB WebAssembly module compiles.
- Keep *Android System WebView* and Chrome updated from the Play Store.
- This is a debug-signed build for your own use. Publishing on Google Play would need a release
  signing key and a developer account.

## Changing things

- App name and id: `capacitor.config.json`.
- Icon: the workflow uses `assets/app-icon/wordcraft-1024.png` from the repo.
- Newer action versions: if GitHub shows warnings about old actions in the workflow, bump the
  `@v4`/`@v2` tags.
